﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    internal class Dataacces
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Con"].ConnectionString);

        public void insertarContacto(Contacto contacto)
        {
            cn.Open();
            SqlCommand command = new SqlCommand("InsertarRegistroAgendaCapas", cn);
            command.CommandType = CommandType.StoredProcedure;


            command.Parameters.AddWithValue("@Nombre", contacto.Nombre);
            command.Parameters.AddWithValue("@Apellido", contacto.Apellido);
            command.Parameters.AddWithValue("@Direccion", contacto.Direccion);
            command.Parameters.AddWithValue("@FechaNacimiento", contacto.FechaNacimiento);
            command.Parameters.AddWithValue("@Celular", contacto.Celular);


            command.ExecuteNonQuery();
            cn.Close();
        }

        public void eliminarContacto(int Id)
        {
            cn.Open();
            SqlCommand command = new SqlCommand("EliminarRegistroAgendaCapas", cn);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@Id", Id);
            command.ExecuteNonQuery();
            cn.Close();
        }

        public void CargarDatos(DataGridView dataGridView)
        {
            cn.Open();

            SqlCommand comando = new SqlCommand("SelectFromAgendaCapas", cn);
            comando.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            dataGridView.DataSource = tabla;
            cn.Close();
        }

        public DataTable BuscarRegistro(string busqueda)
        {
            cn.Open();


            SqlCommand comando = new SqlCommand("BuscarRegistroAgendaCapass", cn);
            comando.CommandType = CommandType.StoredProcedure;

            comando.Parameters.AddWithValue("@Busqueda", busqueda);

            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);

            cn.Close();



            return tabla;
        }
        public void updateContacto(int Id, string Nombre, string Apellido, string Direccion, string FechaNacimiento, string Celular)
        {
            cn.Open();
            SqlCommand command = new SqlCommand("UpdateContacto", cn);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@Id", Id);
            command.Parameters.AddWithValue("@Nombre", Nombre);
            command.Parameters.AddWithValue("@Apellido", Apellido);
            command.Parameters.AddWithValue("@Direccion", Direccion);
            command.Parameters.AddWithValue("@FechaNacimiento", FechaNacimiento);
            command.Parameters.AddWithValue("@Celular", Celular);



            command.ExecuteNonQuery();
            cn.Close();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicBussiness
{
    internal class logicaBusines
    {
        private D_Contacto objec = new D_Contacto();

        public void insertarContacto(Contacto contacto)
        {

            objec.insertarContacto(contacto);

        }

        public DataTable BuscarBusqueda(string busqueda)
        {
            DataTable res = objec.BuscarRegistro(busqueda);
            return res;

        }

        public void updateContac(int Id, string Nombre, string Apellido, string Direccion, string FechaNacimiento, string Celular)
        {
            try
            {

                objec.updateContacto(Id, Nombre, Apellido, Direccion, FechaNacimiento, Celular);
                MessageBox.Show("Actualizado con exito");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar");
            }
        }

        public void cargarDatos(DataGridView dataGridView)
        {
            objec.CargarDatos(dataGridView);
        }

        public void eliminarContacto(int ID)
        {
            try
            {
                objec.eliminarContacto(ID);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar");
            }
        }
    }
}

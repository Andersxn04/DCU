﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Front_END
{
    internal class EntityBase
    {
        public Contacto(string nombre, string apellido, string direccion, string fechaNacimiento, string celular)
        {
            Nombre = nombre;
            Apellido = apellido;
            Direccion = direccion;
            FechaNacimiento = fechaNacimiento;
            Celular = celular;
        }

        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Direccion { get; set; }
        public string FechaNacimiento { get; set; }
        public string Celular { get; set; }


    }
}
    }
}
